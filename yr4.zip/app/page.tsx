import SpaceScene from "./components/space-scene"

export default function Home() {
  return (
    <main>
      <SpaceScene />
    </main>
  )
}

